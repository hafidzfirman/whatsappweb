<?php get_header(); ?>

<div id="container">
	<div id="content" class="inner clearfix">

<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
	<article id="post-<?php the_ID(); ?>" <?php post_class('singular-loop'); ?>>
		<h1 class="entry-title"><?php the_title(); ?></h1>
		<div class="entry-content clearfix">
			<?php the_content(); ?>
			<?php wp_link_pages( array( 'before' => '<p class="post-sub-pages">', 'after' => '</p>', 'next_or_number' => 'next', 'nextpagelink' => __( 'Next Page &raquo;', 'was' ), 'previouspagelink' => __( '&laquo; Previous Page', 'was' ) ) ); ?>
			<?php edit_post_link( __( 'Edit', 'was' ), '<p class="edit-link">', '</p>' ); ?>
		</div>
	</article>
<?php
	// comments_template( '', true );
	endwhile;
?>

    </div>
</div>

<?php get_footer(); ?>