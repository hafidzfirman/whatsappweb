<?php get_header(); ?>

<div id="container">
	<div id="content" class="inner clearfix">

<?php
if ( have_posts() ) while ( have_posts() ) : the_post();

$first_variant = ( get_post_meta(get_the_ID(),'variant',true) ) ? maybe_unserialize(get_post_meta(get_the_ID(),'variant',true))[0] : '';
$first_color = ( get_post_meta(get_the_ID(),'color',true) ) ? maybe_unserialize(get_post_meta(get_the_ID(),'color',true))[0] : '';
$first_size = ( get_post_meta(get_the_ID(),'size',true) ) ? maybe_unserialize(get_post_meta(get_the_ID(),'size',true))[0] : '';

$customer_name = ( isset($_COOKIE['was_userdata_name']) ) ? $_COOKIE['was_userdata_name'] : '';
$customer_address = ( isset($_COOKIE['was_userdata_address']) ) ? $_COOKIE['was_userdata_address'] : '';

$discount_happens = false;
$shit_happens = false;

if( get_post_meta(get_the_ID(),'ware_nostock',true) != 'on' && get_post_meta(get_the_ID(),'ware_price',true) > 0 && get_post_meta(get_the_ID(),'ware_price_sale',true) > 0 && get_post_meta(get_the_ID(),'ware_price_sale',true) < get_post_meta(get_the_ID(),'ware_price',true) ) {
	$discount_happens = true;
	$discount_percentage = floor( 100 - ( get_post_meta(get_the_ID(),'ware_price_sale',true) / get_post_meta(get_the_ID(),'ware_price',true)  * 100 ) );
	$price = get_post_meta(get_the_ID(),'ware_price_sale',true);
} elseif( get_post_meta(get_the_ID(),'ware_nostock',true) != 'on' && get_post_meta(get_the_ID(),'ware_price',true) > 0 ) {
	$price = get_post_meta(get_the_ID(),'ware_price',true);
} else {
	$shit_happens = true;
	$inquiry_text = 'Halo Admin... Saya ingin menanyakan tentang *' . get_the_title() . '*. Bisakah anda membantu saya?

via ' . get_the_permalink();
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('singular-loop singular-ware'); ?>>
    <div class="entry-content clearfix">
		<div id="ware-gallery">
			<div class="primary-fimage">
				<a href="<?php echo get_fimage(get_the_ID(),500); ?>" rel="prettyPhoto[gallery]"><img src="<?php echo get_fimage(get_the_ID(),500); ?>" /></a>
			</div>
			<div class="secondary-fimages">
				<?php
					$fimages = maybe_unserialize(get_post_meta($id,'secondary_fimage',true));
					if( $fimages ) {
						foreach( $fimages as $fimage ) {
							echo '<a href="' . $fimage . '" rel="prettyPhoto[gallery]"><img src="' . $fimage . '" /></a>';
						}
					}
				?>
			</div>
		</div>
		<div id="ware-summary">
			<h1 class="entry-title"><?php the_title(); ?></h1>
			<div id="notform">
			
				<?php if( $shit_happens ) { ?>
					<a id="send_inquiry" href="https://web.whatsapp.com/send?phone=<?php echo maybe_unserialize(get_option('noel_theme_options'))['store_whatsapp']; ?>&text=<?php echo rawurlencode($inquiry_text); ?>" target="_blank"><i class="fa fa-paper-plane"></i> <?php _e( 'Send Inquiry', 'was' ); ?></a>
				<?php } else { ?>
					<div class="ware-price">
						<?php
							if( $discount_happens ) {
								echo '<div class="discount_meta"><span>-' . $discount_percentage . '%</span><del>Rp ' . number_formatter(get_post_meta(get_the_ID(),'ware_price',true)) . '</del></div>';
								echo '<div class="price_per_unit">Rp ' . number_formatter(get_post_meta(get_the_ID(),'ware_price_sale',true)) . ' <span id="addon_total" data-addons=0></span></div>';
							} else {
								echo '<div class="price_per_unit">Rp ' . number_formatter(get_post_meta(get_the_ID(),'ware_price',true)) . ' <span id="addon_total" data-addons=0></span></div>';
							}
						?>
					</div>
					<?php
						echo ware_var( get_the_ID(), 'variant', __( 'Varian:', 'was' ) );
						echo ware_var( get_the_ID(), 'color', __( 'Warna:', 'was' ) );
						echo ware_var( get_the_ID(), 'size', __( 'Ukuran:', 'was' ) );
						
						$addons = maybe_unserialize(get_post_meta( get_the_ID(), 'addons', true ));
						if( $addons ) {
							$c = 1;
							echo '<div class="addons">';
								echo '<p>Tambahan:</p>';
								foreach( $addons as $addon ) {
									if( isset($addon['name']) ) {
										echo '<input type="checkbox" id="addon-' . $c . '" class="addon" value="' . $addon['name'] . '" data-price="' . $addon['price'] . '" autocomplete="off"><label for="addon-' . $c . '" class="noel-lock">' . $addon['name'] . '</label>';
										$c++;
									}
								}
							echo '</div>';
						}
					?>
					<div class="ware-qty clearfix">
						<div class="kuantiti clearfix">
							<div class="kuantiti-minus noel-lock">-</div>
							<input type="number" class="qty" name="qty" min=1 max=999 value=1 data-price="<?php echo $price; ?>">
							<div class="kuantiti-plus noel-lock">+</div>
						</div>
						<div class="summon_buyform"><i class="fa fa-whatsapp"></i> <?php _e( 'Pesan Sekarang', 'was' ); ?></div>
					</div>
					<?php echo marketplace_links(); ?>
				<?php } ?>
				
				<div id="organic-tab">
					<ul class="nav">
						<li class="nav-one"><a href="#description" class="current"><?php _e( 'Deskripsi', 'was' ); ?></a></li>
						<li class="nav-two"><a href="#share"><?php _e( 'Bagikan!', 'was' ); ?></a></li>
					</ul>
					<div class="list-wrap">
						<div id="description">
							<?php the_content(); ?>
							<?php wp_link_pages(); ?>
							
<?php
/*
$cookie_name = "was_userdata_address";
if(!isset($_COOKIE[$cookie_name])) {
    echo "Cookie named '" . $cookie_name . "' is not set!";
} else {
    echo "Cookie '" . $cookie_name . "' is set!<br>";
	// echo "Value is: " . $_COOKIE[$cookie_name];
	
	
	// $x = json_decode($_COOKIE[$cookie_name],true);
	$x = $_COOKIE[$cookie_name];
	echo '<pre>';
	var_dump($x);
	echo '</pre>';
}
*/
?>
							
						</div>
						<div id="share" class="hide">
							<?php echo sharer_links(get_the_title(),get_the_permalink()); ?>
						</div>
					</div>
				</div>
				
				<div class="buyform" style="display:none">
					<div class="buyform_overlayer"></div>
					<div class="buyform_inner">
						<h2><i class="fa fa-whatsapp"></i> <?php _e( 'Beli via WhatsApp', 'was' ); ?></h2>
						<div class="cart_overview clearfix">
							<div class="righty">
								<img src="<?php echo get_fimage(get_the_ID(),250); ?>" />
							</div>
							<div class="lefty">
								<h3><?php echo get_the_title(); ?></h3>
								<table>
									<?php if( get_post_meta( get_the_ID(), 'variant', true ) ) { ?>
										<tr>
											<td><?php _e( 'Varian', 'was' ); ?></td>
											<td>:</td>
											<td class="cart_variant"><?php echo $first_variant; ?></td>
										</tr>
									<?php } ?>
									<?php if( get_post_meta( get_the_ID(), 'color', true ) ) { ?>
										<tr>
											<td><?php _e( 'Warna', 'was' ); ?></td>
											<td>:</td>
											<td class="cart_color"><?php echo $first_color; ?></td>
										</tr>
									<?php } ?>
									<?php if( get_post_meta( get_the_ID(), 'size', true ) ) { ?>
										<tr>
											<td><?php _e( 'Ukuran', 'was' ); ?></td>
											<td>:</td>
											<td class="cart_size"><?php echo $first_size; ?></td>
										</tr>
									<?php } ?>
									<?php if( get_post_meta( get_the_ID(), 'addons', true ) ) { ?>
										<tr>
											<td><?php _e( 'Tambahan', 'was' ); ?></td>
											<td>:</td>
											<td class="cart_addons"><?php _e( 'No Addon', 'was' ); ?></td>
										</tr>
									<?php } ?>
									<tr>
										<td><?php _e( 'Jumlah', 'was' ); ?></td>
										<td>:</td>
										<td class="cart_qty">1</td>
									</tr>
								</table>
								<hr/>
								<div class="price_calc">
									<div><?php _e( 'Sub-Total:', 'was' ); ?></div>
									<div class="subtotal"><?php echo 'Rp ' . number_formatter($price); ?></div>
									<div><?php _e( '* Belum termasuk ongkos kirim.', 'was' ); ?></div>
								</div>
							</div>
						</div>
						<div class="checkout_form clearfix">
							<div class="field_name"><label><i class="fa fa-fw fa-user-circle"></i></label><input type="text" name="pname" placeholder="Nama Lengkap" value="<?php echo $customer_name; ?>"></div>
							<!--
							<div class="field_phone"><label><i class="fa fa-fw fa-mobile-phone"></i></label><input type="text" name="pphone" placeholder="Phone Number"></div>
							<div class="field_email"><label><i class="fa fa-fw fa-envelope"></i></label><input type="email" name="pemail" placeholder="Email Address"></div>
							<div class="field_payment clear">
								<label><i class="fa fa-fw fa-chevron-down"></i></label><select name="ppayment"><?php
									$c = 1;
									$payment_methods = maybe_unserialize(get_option('noel_theme_options'))['payment_methods'];
									foreach( $payment_methods as $option ) {
										$selected = ( $c == 1 ) ? 'selected=selected' : '';
										echo '<option value="' . $option . '" ' . $selected . '>' . $option . '</option>';
										$c++;
									}
								?></select>
							</div>
							-->
							<div class="field_address"><label><i class="fa fa-fw fa-home"></i></label><textarea name="paddress" placeholder="Alamat"><?php echo $customer_address; ?></textarea></div>
							<div class="field_note"><label><i class="fa fa-fw fa-sticky-note"></i></label><textarea name="pnote" placeholder="Catatan"></textarea></div>
							
							<div id="send_buy_message" data-title="<?php echo get_the_title(); ?>" data-variant="<?php echo $first_variant; ?>" data-color="<?php echo $first_color; ?>" data-size="<?php echo $first_size; ?>" data-addons="" data-qty="1" data-price="<?php echo $price; ?>"  data-pname="" data-pphone="" data-pemail="" data-ppayment="<?php echo $payment_methods[0]; ?>" data-paddress="" data-pnote="" data-url="<?php echo get_the_permalink(); ?>"><i class="fa fa-paper-plane"></i> <?php _e( 'Kirim Pesan', 'was' ); ?></div>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div>
</article><!-- #post -->

<?php
	// comments_template( '', true );
	endwhile;
?>

    </div>
</div>

<?php get_footer(); ?>