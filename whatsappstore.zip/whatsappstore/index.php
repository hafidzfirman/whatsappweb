<?php get_header(); ?>

<div id="container">
	<div id="content" class="inner clearfix">
		<?php
			if( is_tax('ware_category') ) {
				echo '<h1>FOOBAR</h1>';
			}
			get_template_part( 'loop', 'index' );
		?>
    </div>
</div>

<?php get_footer(); ?>