<?php if ( ! have_posts() ) : ?>
	<article id="post-0" class="post error404 not-found">
		<h1 class="entry-title"><?php _e( 'Not Found', 'was' ); ?></h1>
		<div class="entry-content">
			<p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'was' ); ?></p>
		</div>
	</article>
<?php
endif;
while ( have_posts() ) : the_post();
	echo render_ware_loop();
endwhile;

/* Our usual pagination */
if ( $wp_query->max_num_pages > 1 ) : ?>
	<nav class="loop-pagination clear">
		<?php echo pagination_bar($wp_query); ?>
	</nav><!-- #page-nav -->
<?php endif; ?>