<?php
if( function_exists('noel_breadcrumb') ) {
	noel_breadcrumb();
}
?>

<div class="featured-pitch inner clearfix">
	<?php echo render_pitches(); ?>
</div>

<div id="footer">
	<div class="footer-upper">
		<div class="inner clearfix">
			<div class="lefty"><i>"Still not sure what to put here."</i> &mdash; Leader</div>
			<div class="righty"><?php echo find_us_at(); ?></div>
		</div>
	</div>
	<div class="footer-mid">
		<div class="inner clearfix">
			<?php if ( !is_active_sidebar('first-widget-area') && !is_active_sidebar('second-widget-area') && !is_active_sidebar('third-widget-area') ) { ?>
				<div class="widget-area">
					<div class="widget_text widget widget_custom_html">
						<h4 class="widget-title">WhatsAppStore</h4>
						<div class="textwidget custom-html-widget"><p>Jl. Sidokapasan gg. 10 no. 2,<br>Surabaya 60145</p><p>Look at <a href="https://www.google.com/maps/place/Sidodadi,+Simokerto,+Surabaya+City,+East+Java+60145/@-7.2362139,112.7490431,20.08z/data=!4m5!3m4!1s0x2dd7f91110be0481:0x1c00c5eb5b53e630!8m2!3d-7.2371147!4d112.7472413" target="_blank" rel="noopener noreferrer"><i class="fa fa-map-marker"></i> Google Maps</a>.</p></div>
					</div>
				</div>
			<?php } else {
				if ( is_active_sidebar( 'first-widget-area' ) ) {
					echo '<div class="widget-area">';
					dynamic_sidebar( 'first-widget-area' );
					echo '</div>';
				}
				if ( is_active_sidebar( 'second-widget-area' ) ) {
					echo '<div class="widget-area">';
					dynamic_sidebar( 'second-widget-area' );
					echo '</div>';
				}
				if ( is_active_sidebar( 'third-widget-area' ) ) {
					echo '<div class="widget-area">';
					dynamic_sidebar( 'third-widget-area' );
					echo '</div>';
				}
			} ?>
		</div>
	</div>
	<div class="footer-lower">
		<div class="inner clearfix">
			<div class="lefty credo">&copy;<?php echo get_the_date('Y'); ?> - <b><?php echo get_bloginfo('name'); ?></b></div>
			<div class="lefty bottom-menu"><?php wp_nav_menu( array( 'theme_location' => 'top-nav-menu', 'depth' => 1, 'container' => false, 'menu_class' => 'menu clearfix' ) ); ?></div>
			<div class="righty powered">Website &#9889; by <a href="https://wordpress.org">Wordpress</a></div>
		</div>
	</div>
</div>

</div><!-- #wrapper -->
</div><!-- #global-wrapper -->
<?php wp_footer(); ?>
</body>
</html>