<?php

/** Theme setup */
add_action( 'after_setup_theme', 'was_setup' );
if ( ! function_exists( 'was_setup' ) ) {
	function was_setup() {
		// Theme supports
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'automatic-feed-links' );
		// add_theme_support( 'custom-header', array(
		// 	'default-image' => get_template_directory_uri() . '/images/header.jpg',
		// ) );
		
		// Register the theme's thumbnail sizes
		add_image_size( 'was500', 500, 300, true );
		add_image_size( 'was250', 250, 150, true );
		// Load text domain
		load_theme_textdomain( 'was', get_template_directory() . '/lang' );
		
		// Register menus
		register_nav_menus( array(
			'top-nav-menu' => __( 'Top Nav Menu', 'was' ),
			'top-nav-mobile-menu' => __( 'Top Nav Menu (Mobile)', 'was' ),
		) );
		
		// MISC
		show_admin_bar(false);
		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		remove_action( 'admin_print_styles', 'print_emoji_styles' );
		
		// kill-gutenberg
		add_filter( 'use_block_editor_for_post', '__return_false' );
	}
}

/** Register Scripts */
if (!is_admin()) add_action('wp_enqueue_scripts', 'was_scripts_enqueue', 111);
function was_scripts_enqueue() {
	
	// kill-gutenberg
	wp_deregister_style('wp-block-library');
	
	wp_enqueue_style( 'was-style', get_stylesheet_uri() );
	
	wp_deregister_style('font-awesome');
	wp_register_style('font-awesome', '//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css');
	wp_enqueue_style('font-awesome');

	wp_deregister_script('jquery');
	wp_register_script('jquery', '//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js', false, null, false);
	wp_enqueue_script('jquery');
	
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) { wp_enqueue_script( 'comment-reply' ); }

	wp_deregister_script('was-js');
	wp_register_script('was-js', get_template_directory_uri() . '/script.js', false, null, true);
	$data = array(
		'home_url' => home_url(),
		'ajaxurl' => admin_url( 'admin-ajax.php' ),
		'store_wa' => maybe_unserialize(get_option('noel_theme_options'))['store_whatsapp'],
	);
	wp_localize_script( 'was-js', 'was_misc_data', $data );
	wp_enqueue_script('was-js');
}

/** Register Sidebar */
add_action( 'widgets_init', 'was_widgets_init' );
function was_widgets_init() {
	register_sidebar(array(
		'name' => __( 'First Widget Area', 'was' ),
		'id'   => 'first-widget-area',
		'description'   => __( 'Choose Widget(s) to display in this area.', 'was' ),
		'before_widget' => '<div class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>'
	));
	register_sidebar(array(
		'name' => __( 'Second Widget Area', 'was' ),
		'id'   => 'second-widget-area',
		'description'   => __( 'Choose Widget(s) to display in this area.', 'was' ),
		'before_widget' => '<div class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>'
	));
	register_sidebar(array(
		'name' => __( 'Third Widget Area', 'was' ),
		'id'   => 'third-widget-area',
		'description'   => __( 'Choose Widget(s) to display in this area.', 'was' ),
		'before_widget' => '<div class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>'
	));
}

/** CMB2 */
if ( file_exists(  __DIR__ . '/cmb2/init.php' ) ) {
  require_once  __DIR__ . '/cmb2/init.php';
} elseif ( file_exists(  __DIR__ . '/CMB2/init.php' ) ) {
  require_once  __DIR__ . '/CMB2/init.php';
}

add_action( 'cmb2_admin_init', 'was_ware_metabox' );
function was_ware_metabox() {
	$cmb_ware = new_cmb2_box( array(
		'id'			=> 'ware_metabox',
		'title'         => esc_html__( 'Ware Metabox', 'was' ),
		'object_types'  => array( 'ware' ),
	) );

	$cmb_ware->add_field( array(
		'name'	=> esc_html__( 'Secondary Fimage', 'was' ),
		'id'	=> 'secondary_fimage',
		'type'	=> 'file_list',
	) );
	$cmb_ware->add_field( array(
		'name'				=> esc_html__( 'Regular Price', 'was' ),
		'id'				=> 'ware_price',
		'type'				=> 'text',
		'attributes'		=> array(
			'type'		=> 'number',
			'pattern'	=> '\d*',
		),
		'sanitization_cb'	=> 'absint',
		'escape_cb'			=> 'absint',
	) );
	$cmb_ware->add_field( array(
		'name'				=> esc_html__( 'Sale Price', 'was' ),
		'id'				=> 'ware_price_sale',
		'type'				=> 'text',
		'attributes'		=> array(
			'type'		=> 'number',
			'pattern'	=> '\d*',
		),
		'sanitization_cb'	=> 'absint',
		'escape_cb'			=> 'absint',
	) );
	$cmb_ware->add_field( array(
		'name'     => esc_html__( 'Category', 'was' ),
		'id'       => 'ware_cat',
		'type'     => 'taxonomy_select', // Or `taxonomy_select_hierarchical`
		'taxonomy' => 'ware_category', // Taxonomy Slug
	) );
	$cmb_ware->add_field( array(
		'name'	=> esc_html__( 'Out of Stock', 'was' ),
		'desc'	=> esc_html__( 'Check this box is no stock is available.', 'was' ),
		'id'	=> 'ware_nostock',
		'type'	=> 'checkbox',
	) );
	$cmb_ware->add_field( array(
		'name'			=> esc_html__( 'Variants', 'was' ),
		'id'			=> 'variant',
		'type'			=> 'text',
		'repeatable'	=> true,
	) );
	$cmb_ware->add_field( array(
		'name'			=> esc_html__( 'Colors', 'was' ),
		'id'			=> 'color',
		'type'			=> 'text',
		'repeatable'	=> true,
	) );
	$cmb_ware->add_field( array(
		'name'			=> esc_html__( 'Sizes', 'was' ),
		'id'			=> 'size',
		'type'			=> 'text',
		'repeatable'	=> true,
	) );
	

	$group_field_id = $cmb_ware->add_field( array(
		'id'          => 'addons',
		'type'        => 'group',
		'options'     => array(
			'group_title'	=> esc_html__( 'Addon {#}', 'was' ), // {#} gets replaced by row number
			'add_button'	=> esc_html__( 'Add Another Addon', 'was' ),
			'remove_button'	=> esc_html__( 'Remove Addon', 'was' ),
			'sortable'		=> true,
			'closed'		=> true,
			'remove_confirm'=> esc_html__( 'Are you sure you want to remove addon?', 'was' ),
		),
	) );
	$cmb_ware->add_group_field( $group_field_id, array(
		'name'			=> esc_html__( 'Name', 'was' ),
		'id'			=> 'name',
		'type'			=> 'text',
	) );
	$cmb_ware->add_group_field( $group_field_id, array(
		'name'			=> esc_html__( 'Price', 'was' ),
		'id'			=> 'price',
		'type'				=> 'text',
		'attributes'		=> array(
			'type'		=> 'number',
			'pattern'	=> '\d*',
		),
		'sanitization_cb'	=> 'absint',
		'escape_cb'			=> 'absint',
	) );
}

/** Register CPT */
add_action( 'init', 'register_ware_cpt' );
function register_ware_cpt() {
	$labels = array(
		'name'                  => _x( 'Products', 'Post type general name', 'was' ),
		'singular_name'         => _x( 'Product', 'Post type singular name', 'was' ),
		'menu_name'             => _x( 'Products', 'Admin Menu text', 'was' ),
		'name_admin_bar'        => _x( 'Product', 'Add New on Toolbar', 'was' ),
		'add_new'               => __( 'Add Product', 'was' ),
		'add_new_item'          => __( 'Add New Product', 'was' ),
		'new_item'              => __( 'New Product', 'was' ),
		'edit_item'             => __( 'Edit Product', 'was' ),
		'view_item'             => __( 'View Product', 'was' ),
		'all_items'             => __( 'All Products', 'was' ),
		'search_items'          => __( 'Search Products', 'was' ),
		'parent_item_colon'     => __( 'Parent Products:', 'was' ),
		'not_found'             => __( 'No products found.', 'was' ),
		'not_found_in_trash'    => __( 'No products found in Trash.', 'was' ),
		'featured_image'        => _x( 'Product Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'was' ),
		'set_featured_image'    => _x( 'Set cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'was' ),
		'remove_featured_image' => _x( 'Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'was' ),
		'use_featured_image'    => _x( 'Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'was' ),
		'archives'              => _x( 'Product archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'was' ),
		'insert_into_item'      => _x( 'Insert into product', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'was' ),
		'uploaded_to_this_item' => _x( 'Uploaded to this product', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'was' ),
		'filter_items_list'     => _x( 'Filter products list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'was' ),
		'items_list_navigation' => _x( 'Products list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'was' ),
		'items_list'            => _x( 'Products list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'was' ),
    );
	register_post_type( 'ware', array(
		'public' => true,
		'labels'  => $labels,
		'menu_icon' => 'dashicons-edit',
		'has_archive' => true,
		'show_in_rest' => true,
		'supports' => array( 'title', 'editor', 'thumbnail', 'comments' ),
	) );
	
	register_taxonomy(
		'ware_category',
		'ware',
		array(
			'label' => __( 'Product Category', 'was' ),
			'rewrite' => array( 'slug' => 'ware_category' ),
			'meta_box_cb' => false,
			'show_in_menu' => true,
			'show_in_rest' => true,
		)
	);
}
function pagination_bar( $custom_query ) {
	$total_pages = $custom_query->max_num_pages;
	$big = 999999;
	
	if ($total_pages > 1){
		$current_page = max(1, get_query_var('paged'));
		
		$base = str_replace( $big, '%#%', get_pagenum_link($big) );
		
		return paginate_links(array(
			'base' => $base,
			'format' => '?paged=%#%',
			'current' => $current_page,
			'total' => $total_pages,
		));
	}
}


function was_top_nav_logo() {
	$heading_tag = ( is_home() || is_front_page() ) ? 'h1' : 'div';
	// return '<' . $heading_tag . ' id="site-title"><a href="' . home_url( '/' ) . '" class="site-title"><img src="" alt="" /></a></' . $heading_tag . '>';
	// $logo = '<svg id="main-logo" class="trans" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 50"><path d="M41.3,12.9h2.8v19.5h8.4v2.8H41.3V12.9z M61.2,12.9c4.6,0,8.4,3.8,8.4,8.4s-3.8,8.4-8.4,8.4s-8.4-3.8-8.4-8.4 S56.6,12.9,61.2,12.9z M61.2,26.9c3.1,0,5.6-2.5,5.6-5.6s-2.5-5.6-5.6-5.6s-5.6,2.5-5.6,5.6C55.6,24.3,58.1,26.8,61.2,26.9 L61.2,26.9z M55.6,32.4h11.2v2.8H55.6V32.4z M91.5,35.2h-2.8v-2c-1.8,1.3-4,1.9-6.2,1.9c-6.2,0-11.2-4.9-11.3-11.1 s4.9-11.2,11.1-11.3c3.3,0,6.4,1.4,8.6,3.9l-2.1,1.8c-3.1-3.5-8.4-3.8-11.9-0.7c-3.5,3.1-3.8,8.4-0.7,11.9c1.6,1.8,3.9,2.8,6.3,2.8 c2.4,0,4.6-1,6.1-2.8h-7.6v-2.8h10.3L91.5,35.2z M101.8,12.9c4.6,0,8.4,3.8,8.4,8.4s-3.8,8.4-8.4,8.4s-8.4-3.8-8.4-8.4 C93.3,16.7,97.1,12.9,101.8,12.9C101.7,12.9,101.8,12.9,101.8,12.9L101.8,12.9z M101.8,26.9c3.1,0,5.6-2.5,5.6-5.6s-2.5-5.6-5.6-5.6 c-3.1,0-5.6,2.5-5.6,5.6C96.2,24.4,98.7,26.9,101.8,26.9L101.8,26.9z M96.2,32.4h11.2v2.8H96.2V32.4z M113.2,12.9h2.8v22.3h-2.8 V12.9z M119.8,12.9h2.8c0.1,0,0.3,0,0.4,0c4.6-0.5,8.8,2.8,9.3,7.4c0.5,4.6-2.8,8.8-7.4,9.3c-0.6,0.1-1.2,0.1-1.8,0h-0.4v5.6h-2.8 V12.9z M122.6,15.7v11.1h0.4c3.1,0.4,5.9-1.7,6.3-4.8c0.4-3.1-1.7-5.9-4.8-6.3c-0.5-0.1-1-0.1-1.5,0 C122.9,15.6,122.8,15.7,122.6,15.7L122.6,15.7z M142.8,14.5l-2.1,1.6c-1-1.1-2.8-1.1-3.8-0.1c-0.5,0.4-0.8,1-0.8,1.7v0.2 c0,1.2,0.9,2.1,2.5,2.2c6.4,0.4,9.4,3.4,9.4,7.4v0.3c-0.5,4.5-4.5,7.8-9.1,7.4c-2-0.2-3.8-1.1-5.2-2.6l2.1-1.7 c1,1.1,2.4,1.7,3.9,1.6c2.8,0.1,5.2-1.9,5.5-4.7v-0.2c0-3.7-3.7-4.4-6.8-4.7c-2.9-0.3-5.1-2.1-5.1-4.8v-0.1c0.2-2.9,2.6-5.1,5.5-5 C140.3,12.9,141.8,13.5,142.8,14.5L142.8,14.5z M158.9,32.3c3.5,0,6.2-3.8,6.2-8.4V12.7h2.8v11.2c0,6.2-4,11.1-9,11.1 c-5,0-9-5-9-11.1V12.7h2.8v11.2C152.7,28.6,155.4,32.4,158.9,32.3L158.9,32.3z M189.5,35.1h-2.8V21.2l-6.5,8.4l-6.5-8.4v13.9H171 V12.9l9.2,12.2l9.2-12.2L189.5,35.1z"/><path d="M27.8,9.5c0-4.2-3.4-7.6-7.6-7.6s-7.6,3.4-7.6,7.6v23l6.3,4.5v11h2.7V37l6.3-4.5L27.8,9.5z M25.1,22.4L21.6,26 v-3.4l3.6-3.6V22.4z M15.3,19l3.6,3.6V26l-3.6-3.6V19z M25.1,15.2l-4.9,4.9l-4.9-5v-3.4l4.9,4.9l4.9-4.9L25.1,15.2z M20.2,4.6 c2.2,0,4.2,1.5,4.8,3.7L20.2,13l-4.8-4.7C16,6.1,18,4.5,20.2,4.6L20.2,4.6z M15.3,31.2v-5l3.6,3.6v4L15.3,31.2z M21.6,33.8v-4 l3.6-3.6v5L21.6,33.8z"/></svg>';
	$logo = '<img alt="' . get_bloginfo('name') . '" src="' . get_template_directory_uri() . '/img/logo.png" />';
	return '<' . $heading_tag . ' id="site-title"><a href="' . home_url( '/' ) . '">' . $logo . '</a></' . $heading_tag . '>';
}

function was_top_nav_cat() {
	$terms = get_terms( array(
		'taxonomy' => 'ware_category',
		'hide_empty' => false
	) );

	$output = '<div id="top-nav-cat" class="top-nav"><div class="overlayer"></div><div class="top-menu-shoukan"><i class="fa fa-list"></i> ' . __( 'Category', 'was' ) . '</div><div class="top-nav-hidden-menu">';
		$output .= '<ul>';
		foreach( $terms as $cat ) {
			$output .= '<li><a href="' . get_term_link($cat->term_id,'ware_category') . '"><span class="cat-name">' . $cat->name . '</span><b class="cat-count"><i>' . $cat->count . '</i></b></a></li>';
		}
		// $output .= '<li class="cat-menu-all"><a href="#"><b>All</b> Products &gt;</a></li>';
		$output .= '</ul>';
	$output .= '</div></div>';
	
	return $output;
}

function was_top_nav_menu() {
	$output = '<div id="top-nav-menu" class="top-nav"><div class="overlayer"></div><div class="top-menu-shoukan"><i class="fa fa-navicon"></i> ' . __( 'Menu', 'was' ) . '</div><div class="top-nav-hidden-menu">';
		$output .= wp_nav_menu( array(
			'theme_location' => 'top-nav-menu',
			'depth' => 2,
			'container' => false,
			'echo' => false,
		) );
	$output .= '</div></div>';
	
	return $output;
}

function was_top_nav_search() {
	$output = '<div id="top-nav-search">';
		$output .= '<form id="top-nav-searchform" method="get" action="' . home_url() . '">';
			$output .= '<label for="top-nav-s"><i class="fa fa-search"></i></label>';
			$output .= '<input id="top-nav-s" name="s" placeholder="' . __( 'Find products...', 'was' ) . '" />';
		$output .= '</form>';
	$output .= '</div>';
	
	return $output;
}

/*
add_filter( 'wp_nav_menu_items', 'was_mobile_menu_hax', 10, 2 );
function was_mobile_menu_hax( $items, $args ) {
    if ( $args->theme_location == 'top-nav-mobile-menu') {
        return '<li><form method="GET" action="' . home_url() . '"><label for="m-searchform"><i class="fa fa-search"></i></label><input type="text" id="m-searchform" name="s" placeholder="' . __( 'Find wares...', 'was' ) . '"></form></li>' . $items;
    }
}
*/
function was_top_mobile_menu() {
	$output = '<div id="top-nav-mobile-menu" class="top-nav"><div class="overlayer"></div><div class="top-menu-shoukan"><i class="fa fa-navicon"></i></div><div class="top-nav-hidden-menu">';
		$output .= '<form method="GET" action="' . home_url() . '"><label for="m-searchform"><i class="fa fa-search"></i></label><input type="text" id="m-searchform" name="s" placeholder="' . __( 'Find wares...', 'was' ) . '"></form>';
		$output .= wp_nav_menu( array(
			'theme_location' => 'top-nav-mobile-menu',
			'depth' => 2,
			'container' => false,
			'echo' => false,
		) );
	$output .= '</div></div>';
	
	return $output;
}


add_action( 'pre_get_posts', 'target_main_category_query_with_conditional_tags' );
function target_main_category_query_with_conditional_tags( $query ) {
	if ( !is_admin() && is_home() && $query->is_main_query() && isset($_GET['nquery']) && $_GET['nquery'] == 1 ) {
		if( isset($_GET['orderby']) ) {
			if( $_GET['orderby'] == 'cheapest' ) {
				$query->set( 'order', 'ASC' );
				$query->set( 'orderby', 'meta_value_num' );
				$query->set( 'meta_key', 'ware_price' );
			} elseif( $_GET['orderby'] == 'priciest' ) {
				$query->set( 'order', 'DESC' );
				$query->set( 'orderby', 'meta_value_num' );
				$query->set( 'meta_key', 'ware_price' );
			}
		}
	}
	if ( !is_admin() && is_home() && $query->is_main_query() ) {
		$query->set( 'post_type', 'ware' );
	}
}

function get_fimage($post_id,$size=250) {
	if( has_post_thumbnail() ) {
		return wp_get_attachment_image_src( get_post_thumbnail_id($post_id), 'was'.$size )[0];
	} else {
		return get_template_directory_uri().'/img/no-image.jpg';
	}
}
function number_formatter($number) {
	return number_format($number,0,',','.');
}
function get_price($post_id) {
	$message = __( 'Call us', 'was' );
	if( get_post_meta($post_id,'ware_price',true) > 0 ) {
		if( get_post_meta($post_id,'ware_price_sale',true) > 0 && get_post_meta($post_id,'ware_price_sale',true) < get_post_meta($post_id,'ware_price',true) ) {
			return '<del>Rp ' . number_formatter(get_post_meta($post_id,'ware_price',true)) . '</del><span>Rp ' . number_formatter(get_post_meta($post_id,'ware_price_sale',true)) . '</span>';
		} else {
			return '<span>Rp ' . number_formatter(get_post_meta($post_id,'ware_price',true)) . '</span>';
		}
	} else {
		$wa_number = maybe_unserialize(get_option('noel_theme_options'))['store_whatsapp'];
		$inquiry_text = 'Hello Admin... I wish to make an inquiry about *' . get_the_title($post_id) . '*. Could you help me?

via ' . get_the_permalink($post_id);
		
		return '<a href="https://web.whatsapp.com/send?phone=' . $wa_number . '&text=' . rawurlencode($inquiry_text) . '" target="_blank"><i class="fa fa-phone"></i>' . $message . '</a>';
	}
}

function render_ware_loop() {
	$id = get_the_ID();
	$title = get_the_title();
	$link = get_the_permalink();
	$price = get_price($id);
	$primary_fimage = get_fimage($id);
	if( get_post_meta($id,'secondary_fimage',true) ) {
		$f = array_key_first(maybe_unserialize(get_post_meta($id,'secondary_fimage',true)));
		$secondary_fimage = get_post_meta($id,'secondary_fimage',true)[$f];
	} else {
		$secondary_fimage = $primary_fimage;
	}
	
	$output = '<article id="post-' . $id . '" class="ware-loop">';
		$output .= '<a class="loop-fimage" style="background-image:url(' . $secondary_fimage . ')" href="' . $link . '">';
			if( get_post_meta($id,'ware_nostock',true) == 'on' ) {
				$output .= '<span class="nostock">' . __( 'Out of Stock', 'was' ) . '</span>';
			}
			if( get_post_meta($id,'ware_price_sale',true) > 0 && get_post_meta($id,'ware_price_sale',true) < get_post_meta($id,'ware_price',true) ) {
				$discount = 100 - ( get_post_meta($id,'ware_price_sale',true) / get_post_meta($id,'ware_price',true)  * 100 );
				$output .= '<span class="discount">-' . floor($discount) . '%</span>';
			}
			$output .= '<img alt="' . $title . '" src="' . get_fimage($id) . '" />';
		$output .= '</a>';
		$output .= '<h2 class="ellipsis"><a href="' . $link . '">' . $title . '</a></h2>';
		$output .= '<div class="price">' . $price . '</div>';
	$output .= '</article>';
	
	return $output;
}


function noel_breadcrumb(){
	$showOnHome = 0; // 1 - show breadcrumbs on the homepage, 0 - don't show
	$delimiter = '<i class="fa fa-chevron-right"></i>'; // delimiter between crumbs
	$home = '<i class="fa fa-home"></i> ' . __( 'Home', 'was' ); // text for the 'Home' link
	$showCurrent = 1; // 1 - show current post/page title in breadcrumbs, 0 - don't show
	$before = '<span class="current">'; // tag before the current crumb
	$after = '</span>'; // tag after the current crumb
	
	global $post;
	$homeLink = get_bloginfo('url');
	if (is_home() || is_front_page()) {
		if ($showOnHome == 1) {
			echo '<div id="crumbs" class="inner"><a href="' . $homeLink . '">' . $home . '</a></div>';
		}
	} else {
		echo '<div id="crumbs" class="inner"><a href="' . $homeLink . '">' . $home . '</a> ' . $delimiter . ' ';
		if (is_category()) {
			$thisCat = get_category(get_query_var('cat'), false);
			if ($thisCat->parent != 0) {
				echo get_category_parents($thisCat->parent, true, ' ' . $delimiter . ' ');
			}
			echo $before . 'Archive by category "' . single_cat_title('', false) . '"' . $after;
		} elseif (is_search()) {
			echo $before . 'Search results for "' . get_search_query() . '"' . $after;
		} elseif (is_day()) {
			echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
			echo '<a href="' . get_month_link(get_the_time('Y'), get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . $delimiter . ' ';
			echo $before . get_the_time('d') . $after;
		} elseif (is_month()) {
			echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
			echo $before . get_the_time('F') . $after;
		} elseif (is_year()) {
			echo $before . get_the_time('Y') . $after;
		} elseif (is_single() && !is_attachment()) {
			if (get_post_type() != 'post') {
				$post_type = get_post_type_object(get_post_type());
				$slug = $post_type->rewrite;
				echo '<a href="' . $homeLink . '/' . $slug['slug'] . '/">' . $post_type->labels->singular_name . '</a>';
				if ($showCurrent == 1) {
					echo ' ' . $delimiter . ' ' . $before . get_the_title() . $after;
				}
			} else {
				$cat = get_the_category();
				$cat = $cat[0];
				$cats = get_category_parents($cat, true, ' ' . $delimiter . ' ');
				if ($showCurrent == 0) {
					$cats = preg_replace("#^(.+)\s$delimiter\s$#", "$1", $cats);
				}
				echo $cats;
				if ($showCurrent == 1) {
					echo $before . get_the_title() . $after;
				}
			}
		} elseif (!is_single() && !is_page() && get_post_type() != 'post' && !is_404()) {
			$post_type = get_post_type_object(get_post_type());
			echo $before . $post_type->labels->singular_name . $after;
		} elseif (is_attachment()) {
			$parent = get_post($post->post_parent);
			$cat = get_the_category($parent->ID);
			$cat = $cat[0];
			echo get_category_parents($cat, true, ' ' . $delimiter . ' ');
			echo '<a href="' . get_permalink($parent) . '">' . $parent->post_title . '</a>';
			if ($showCurrent == 1) {
				echo ' ' . $delimiter . ' ' . $before . get_the_title() . $after;
			}
		} elseif (is_page() && !$post->post_parent) {
			if ($showCurrent == 1) {
				echo $before . get_the_title() . $after;
			}
		} elseif (is_page() && $post->post_parent) {
			$parent_id  = $post->post_parent;
			$breadcrumbs = array();
			while ($parent_id) {
				$page = get_page($parent_id);
				$breadcrumbs[] = '<a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';
				$parent_id  = $page->post_parent;
			}
			$breadcrumbs = array_reverse($breadcrumbs);
			for ($i = 0; $i < count($breadcrumbs); $i++) {
				echo $breadcrumbs[$i];
				if ($i != count($breadcrumbs)-1) {
					echo ' ' . $delimiter . ' ';
				}
			}
			if ($showCurrent == 1) {
				echo ' ' . $delimiter . ' ' . $before . get_the_title() . $after;
			}
		} elseif (is_tag()) {
			echo $before . 'Posts tagged "' . single_tag_title('', false) . '"' . $after;
		} elseif (is_author()) {
			global $author;
			$userdata = get_userdata($author);
			echo $before . 'Articles posted by ' . $userdata->display_name . $after;
		} elseif (is_404()) {
			echo $before . 'Error 404' . $after;
		}
		if (get_query_var('paged')) {
			if (is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author()) {
				echo ' (';
			}
			echo __('Page') . ' ' . get_query_var('paged');
			if (is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author()) {
				echo ')';
			}
		}
		echo '</div>';
	}
}








class noel_searchform extends WP_Widget {
	function __construct() {
		parent::__construct(
			'noel-searchform', 
			__('Searchform', 'was'), 
			array( 'description' => __( 'Display a searchform.', 'was' ), ) 
		);
	}

	public function widget( $args, $instance ) {
		static $x = 0; $x++;
		$id = 'widget-'.$x;
		
		echo $args['before_widget'];
		
		echo '<form id="widget-searchform-' . $id . '" method="get" action="' . home_url() . '"><label for="widget-search-' . $id . '"><i class="fa fa-search"></i></label><input id="widget-search-' . $id . '" name="s" placeholder="Find wares..."></form>';

		echo $args['after_widget'];
	}

	public function form( $instance ) {}
	public function update( $new_instance, $old_instance ) {}
}
class noel_callus extends WP_Widget {
	function __construct() {
		parent::__construct(
			'noel-callus', 
			__('Call Us', 'was'), 
			array( 'description' => __( 'Display call methods.', 'was' ), ) 
		);
	}

	public function widget( $args, $instance ) {

		$phone = ( $instance['phone'] ) ? $instance['phone'] : '';
		$whatsapp = ( $instance['whatsapp'] ) ? $instance['whatsapp'] : '';
		$email = ( $instance['email'] ) ? $instance['email'] : '';
		$note = ( $instance['note'] ) ? $instance['note'] : '';

		$title = apply_filters( 'widget_title', $instance['title'] );
		$default_title = __('Tag Cloud', 'was');
		echo $args['before_widget'];
		if ( ! empty( $title ) ) {
			echo $args['before_title'] . $title . $args['after_title'];
		} else {
			echo $args['before_title'] . $default_title . $args['after_title'];
		}
		
		echo '<div class="call-us">';
			echo '<div class="methods clearfix">';
				if ( ! empty( $phone ) ) {
					echo '<a href="tel:+' . $phone . '"><i class="fa fa-phone"></i> ' . __( 'Phone', 'was' ) . '</a>';
				}
				if ( ! empty( $whatsapp ) ) {
					echo '<a href="https://web.whatsapp.com/send?phone=' . $whatsapp . '" target="_blank"><i class="fa fa-whatsapp"></i> ' . __( 'WhatsApp', 'was' ) . '</a>';
				}
				if ( ! empty( $email ) ) {
					echo '<a href="mailto:' . $email . '"><i class="fa fa-envelope"></i> ' . __( 'Email', 'was' ) . '</a>';
				}
			echo '</div>';
			if ( ! empty( $note ) ) {
				echo '<div class="note">' . $note . '</div>';
			}
		echo '</div>';

		echo $args['after_widget'];
	}

	public function form( $instance ) {
		$title = ( isset($instance['title']) ) ? $instance['title'] : '';
		$phone = ( isset($instance['phone']) ) ? $instance['phone'] : '';
		$whatsapp = ( isset($instance['whatsapp']) ) ? $instance['whatsapp'] : '';
		$email = ( isset($instance['email']) ) ? $instance['email'] : '';
		$note = ( isset($instance['note']) ) ? $instance['note'] : '';

		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'was' ); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'phone' ); ?>"><?php _e( 'Phone:', 'was' ); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'phone' ); ?>" name="<?php echo $this->get_field_name( 'phone' ); ?>" type="text" value="<?php echo esc_attr( $phone ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'whatsapp' ); ?>"><?php _e( 'WhatsApp:', 'was' ); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'whatsapp' ); ?>" name="<?php echo $this->get_field_name( 'whatsapp' ); ?>" type="text" value="<?php echo esc_attr( $whatsapp ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'email' ); ?>"><?php _e( 'Email:', 'was' ); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'email' ); ?>" name="<?php echo $this->get_field_name( 'email' ); ?>" type="email" value="<?php echo esc_attr( $email ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'note' ); ?>"><?php _e( 'Notes:', 'was' ); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'note' ); ?>" name="<?php echo $this->get_field_name( 'note' ); ?>" type="text" value="<?php echo esc_attr( $note ); ?>" />
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['phone'] = ( ! empty( $new_instance['phone'] ) ) ? strip_tags( $new_instance['phone'] ) : '';
		$instance['whatsapp'] = ( ! empty( $new_instance['whatsapp'] ) ) ? strip_tags( $new_instance['whatsapp'] ) : '';
		$instance['email'] = ( ! empty( $new_instance['email'] ) ) ? strip_tags( $new_instance['email'] ) : '';
		$instance['note'] = ( ! empty( $new_instance['note'] ) ) ? strip_tags( $new_instance['note'] ) : '';
		return $instance;
	}
}

add_action( 'widgets_init', 'noel_awan_tridi_widget' );
function noel_awan_tridi_widget() {
	
}

add_action('widgets_init', 'orluk_widget_slayer');
function orluk_widget_slayer() {
	// remove unnecessary widgets
	if(function_exists('unregister_sidebar_widget')) {
		unregister_widget('WP_Widget_Search');
	}
	
	// add new widgets
	register_widget( 'noel_searchform' );
	register_widget( 'noel_callus' );
}


add_action( 'cmb2_admin_init', 'yourprefix_register_repeatable_group_field_metabox' );
function yourprefix_register_repeatable_group_field_metabox() {

	$cmb_options = new_cmb2_box( array(
		'id'           => 'noel_theme_options',
		'title'        => esc_html__( 'Theme Options', 'was' ),
		'object_types' => array( 'options-page' ),
		'option_key'      => 'noel_theme_options', // The option key and admin menu page slug.
		'icon_url'        => 'dashicons-palmtree', // Menu icon. Only applicable if 'parent_slug' is left empty.
	) );
	
	
	$cmb_options->add_field( array(
		'name'    => esc_html__( 'Store Details', 'was' ),
		'id'      => 'store_details_title',
		'type'    => 'title',
	) );
	$cmb_options->add_field( array(
		'name'			=> esc_html__( 'WhatsApp Number', 'was' ),
		'description'	=> esc_html__( 'Start with your country code without plus sign (ex: 62 for Indonesia)', 'was' ),
		'id'			=> 'store_whatsapp',
		'type'			=> 'text',
		'attributes'	=> array(
			'placeholder'	=> 'ex: 6285232900900',
		),
	) );
	
	$cmb_options->add_field( array(
		'name'    => esc_html__( 'Banner Carousel', 'was' ),
		'id'      => 'banner_carousel_title',
		'type'    => 'title',
	) );
	$cmb_options->add_field( array(
		'name'			=> esc_html__( 'Banner Images', 'was' ),
		'id'			=> 'banners',
		'type'			=> 'file_list',
	) );
	
	$cmb_options->add_field( array(
		'name'    => esc_html__( 'Social Links', 'was' ),
		'id'      => 'social_links_title',
		'type'    => 'title',
	) );
	$cmb_options->add_field( array(
		'name'    => esc_html__( 'Facebook', 'was' ),
		'id'      => 'facebook',
		'type'    => 'text_url',
		'attributes'	=> array(
			'placeholder'	=> 'ex: https://www.facebook.com/pg/Internet-Historian-474202776251248',
		),
	) );
	$cmb_options->add_field( array(
		'name'    => esc_html__( 'Twitter', 'was' ),
		'id'      => 'twitter',
		'type'    => 'text_url',
		'attributes'	=> array(
			'placeholder'	=> 'ex: https://twitter.com/NetHistorian',
		),
	) );
	$cmb_options->add_field( array(
		'name'    => esc_html__( 'Instagram', 'was' ),
		'id'      => 'instagram',
		'type'    => 'text_url',
		'attributes'	=> array(
			'placeholder'	=> 'ex: https://www.instagram.com/theinternethistorian',
		),
	) );
	$cmb_options->add_field( array(
		'name'    => esc_html__( 'Youtube', 'was' ),
		'id'      => 'youtube',
		'type'    => 'text_url',
		'attributes'	=> array(
			'placeholder'	=> 'ex: https://www.youtube.com/channel/UCR1D15p_vdP3HkrH8wgjQRw',
		),
	) );
	
	$cmb_options->add_field( array(
		'name'    => esc_html__( 'Marketplace Links', 'was' ),
		'id'      => 'marketplace_links_title',
		'type'    => 'title',
	) );
	$cmb_options->add_field( array(
		'name'    => esc_html__( 'Tokopedia', 'was' ),
		'id'      => 'tokopedia',
		'type'    => 'text_url',
		'attributes'	=> array(
			'placeholder'	=> 'ex: https://www.tokopedia.com/shadythemes',
		),
	) );
	$cmb_options->add_field( array(
		'name'    => esc_html__( 'Bukalapak', 'was' ),
		'id'      => 'bukalapak',
		'type'    => 'text_url',
		'attributes'	=> array(
			'placeholder'	=> 'ex: https://www.bukalapak.com/u/shadythemes',
		),
	) );
	$cmb_options->add_field( array(
		'name'    => esc_html__( 'Shopee', 'was' ),
		'id'      => 'shopee',
		'type'    => 'text_url',
		'attributes'	=> array(
			'placeholder'	=> 'ex: https://shopee.co.id/shadythemes',
		),
	) );
	$cmb_options->add_field( array(
		'name'    => esc_html__( 'Lazada', 'was' ),
		'id'      => 'lazada',
		'type'    => 'text_url',
		'attributes'	=> array(
			'placeholder'	=> 'ex: https://www.lazada.co.id/shop/shadythemes',
		),
	) );

	$cmb_options->add_field( array(
		'name'    => esc_html__( 'Featured Pitch', 'was' ),
		'id'      => 'featured_pitch_title',
		'type'    => 'title',
	) );
	$group_field_id = $cmb_options->add_field( array(
		'id'          => 'pitches',
		'type'        => 'group',
		'description' => esc_html__( 'Pitch Quotes (Only the first 3 will be displayed)', 'was' ),
		'options'     => array(
			'group_title'	=> esc_html__( 'Pitch {#}', 'was' ), // {#} gets replaced by row number
			'add_button'	=> esc_html__( 'Add Another Pitch', 'was' ),
			'remove_button'	=> esc_html__( 'Remove Pitch', 'was' ),
			'sortable'		=> true,
			'closed'		=> true,
			'remove_confirm'=> esc_html__( 'Are you sure you want to remove pitch?', 'was' ),
		),
	) );
	$cmb_options->add_group_field( $group_field_id, array(
		'name'			=> esc_html__( 'Pitch Icon', 'was' ),
		'id'			=> 'icon',
		'type'			=> 'text_small',
		'attributes'	=> array(
			'placeholder'	=> 'ex: fa-phone',
		),
	) );
	$cmb_options->add_group_field( $group_field_id, array(
		'name'			=> esc_html__( 'Pitch Title', 'was' ),
		'id'			=> 'title',
		'type'			=> 'text',
		'attributes'	=> array(
			'placeholder'	=> 'ex: Open 23/7/365',
		),
	) );
	$cmb_options->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Pitch Content', 'was' ),
		'id'   => 'text',
		'type' => 'wysiwyg',
		'attributes'	=> array(
			'placeholder'	=> 'ex: We give you the best service out of everyone else in the same field.',
		),
	) );
	
	$cmb_options->add_field( array(
		'name'    => esc_html__( 'Payment Methods', 'was' ),
		'id'      => 'payment_method_title',
		'type'    => 'title',
	) );
	$cmb_options->add_field( array(
		'name'			=> esc_html__( 'Paymend Methods', 'was' ),
		'id'			=> 'payment_methods',
		'type'			=> 'text',
		'attributes'	=> array(
			'placeholder'	=> 'ex: https://www.youtube.com/channel/UCR1D15p_vdP3HkrH8wgjQRw',
		),
		'repeatable'	=> true,
	) );

}

function render_pitches() {
	$pitches = maybe_unserialize(get_option('noel_theme_options'))['pitches'];
	$output = '';
	
	if( $pitches ) {
		$c = 0;
		foreach( $pitches as $pitch ) {
			if( $c < 3 ) {
				$output .= '<div class="pitch"><div class="icon"><i class="fa ' . $pitch['icon'] . '"></i></div><div class="text"><h3 class="pitch-title">' . strip_tags($pitch['title']) . '</h3><div class="pitch-detail">' . $pitch['text'] . '</div></div></div>';
				$c++;
			}
		}
	}
	
	return $output;
}
function find_us_at() {
	$slinks = maybe_unserialize(get_option('noel_theme_options'));
	$links = '';
	if( $slinks['facebook'] ) {
		$links .= '<a class="fa fa-facebook-square" href="' . $slinks['facebook'] . '"></a>';
	}
	if( $slinks['twitter'] ) {
		$links .= '<a class="fa fa-twitter" href="' . $slinks['twitter'] . '"></a>';
	}
	if( $slinks['instagram'] ) {
		$links .= '<a class="fa fa-instagram" href="' . $slinks['instagram'] . '"></a>';
	}
	if( $slinks['youtube'] ) {
		$links .= '<a class="fa fa-youtube-play" href="' . $slinks['youtube'] . '"></a>';
	}
	
	if( $links ) {
		return sprintf( __( 'Find us at: %s', 'was' ), $links );
	}
}
function marketplace_links() {
	$slinks = maybe_unserialize(get_option('noel_theme_options'));
	$links = '<div class="marketplace-links"><p>' . __( 'You can also find our products at your favorite marketplaces.', 'was' ) . '</p><p>';
	if( $slinks['tokopedia'] ) {
		$links .= '<a href="' . $slinks['tokopedia'] . '" target="_blank"><img src="https://cdn.staticaly.com/favicons/tokopedia.com" /></a>';
	}
	if( $slinks['bukalapak'] ) {
		$links .= '<a href="' . $slinks['bukalapak'] . '" target="_blank"><img src="https://cdn.staticaly.com/favicons/bukalapak.com" /></a>';
	}
	if( $slinks['shopee'] ) {
		$links .= '<a href="' . $slinks['shopee'] . '" target="_blank"><img src="https://cdn.staticaly.com/favicons/shopee.co.id" /></a>';
	}
	if( $slinks['shopee'] ) {
		$links .= '<a href="' . $slinks['shopee'] . '" target="_blank"><img src="https://cdn.staticaly.com/favicons/lazada.co.id" /></a>';
	}
	$links .= '</p></div>';
	
	return $links;
}
function sharer_links($title,$url) {
	$title_e = rawurlencode($title);
	$text = 'Found this awesome site here, you might want to check it out: ';
	$text_e = rawurlencode($text);
	// $email = rawurlencode($email);
	$user_id = 'shadythemes';
	$hashtags = 'shadythemes';
	
	$links = '';
	$links .= '<a href="https://web.whatsapp.com/send?text=' . $title_e . '%0A%0A' . $url . '" target="_blank"><i class="fa fa-fw fa-whatsapp"></i> Send</a>';
	$links .= '<a href="https://line.me/R/msg/text/?' . $title_e . '%0A%0A' . $url . '" target="_blank"><i class="fa fa-fw fa-wechat"></i> Line It!</a>';
	$links .= '<a href="https://www.facebook.com/sharer/sharer.php?u=' . $url . '" target="_blank"><i class="fa fa-fw fa-facebook-square"></i> Share</a>';
	$links .= '<a href="https://twitter.com/intent/tweet?text=' . $title_e . '%0A%0A' . $url . '" target="_blank"><i class="fa fa-fw fa-twitter"></i> Tweet</a>';
	// $links .= '<span class="share_via_email"><a class="sharer_popup"><i class="fa fa-fw fa-envelope-square"></i> Email</a><div class="overlayer"></div><div class="sharer_form"><form><input type="email" name="email" placeholder="' . __( 'Type in an email address...', 'was' ) . '"><input type="submit" value="Share"></form></div></span>';
	$links .= '<span class="share_via_email"><a class="sharer_popup"><i class="fa fa-fw fa-envelope-square"></i> Email</a><div class="overlayer"></div><div class="sharer_form sharer_mailto"><input type="email" name="email" placeholder="' . __( 'Type in an email address...', 'was' ) . '" data-content="subject=' . $title . '&body=' . $text . $url . '"><a class="sharer_a">' . __( 'Share', 'was' ) . '</a></div></span>';
	
/*
// messaging apps
$links .= '<a href="https://t.me/share/url?url=' . $url . '&text=' . $title . '&to=' . $phone . '" target="_blank"><i class="fa fa-fw fa-vk"></i> Send</a>';
$links .= '<a href="threema://compose?text=' . $url . '&id=' . $user_id . '" target="_blank"><i class="fa fa-fw fa-th"></i> Send</a>';

// standard
$links .= '<a href="https://www.facebook.com/sharer.php?u=' . $url . '';
$links .= '<a href="https://twitter.com/intent/tweet?url=' . $url . '&text=' . $title . '&via=' . $user_id . '&hashtags=' . $hashtags . '';

// email
$links .= '<a href="http://compose.mail.yahoo.com/?to=' . $email . '&subject=' . $title . '&body=' . $url . '" target="_blank"><i class="fa fa-fw fa-whatsapp"></i> Send</a>';
$links .= '<a href="https://mail.google.com/mail/?view=cm&to=' . $email . '&su=' . $title . '&body=' . $url . '&bcc=' . $email . '&cc=' . $email . '';
$links .= '<a href="mailto:' . $email . '?subject=' . $title . '&body=' . $text . '" target="_blank"><i class="fa fa-fw fa-envelope-square"></i> Send</a>';

// dark zone 
$links .= '<a href="https://www.blogger.com/blog-this.g?u=' . $url . '&n=' . $title . '&t=' . $text . '" target="_blank"><i class="fa fa-fw fa-bold"></i> Send</a>';
$links .= '<a href="http://www.example.com/website_where_you_installed_wordpress/wp-admin/press-this.php?u=' . $url . '&t=' . $title . '&s=' . $text . '&i=' . $image . '';
$links .= '<a href="sms:' . $phone . '?body=' . $text . '';
$links .= '<a href="http://digg.com/submit?url=' . $url . '" target="_blank"><i class="fa fa-fw fa-digg"></i> Send</a>';
$links .= '<a href="https://news.ycombinator.com/submitlink?u=' . $url . '&t=' . $title . '';
$links .= '<a href="http://service.weibo.com/share/share.php?url=' . $url . '&appkey=&title=' . $title . '&pic=&ralateUid=" target="_blank"><i class="fa fa-fw fa-whatsapp"></i> Send</a>';
$links .= '<a href="http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=' . $url . '" target="_blank"><i class="fa fa-fw fa-whatsapp"></i> Send</a>';
$links .= '<a href="http://surfingbird.ru/share?url=' . $url . '&description=' . $text . '&screenshot=' . $image . '&title=' . $title . '" target="_blank"><i class="fa fa-fw fa-whatsapp"></i> Send</a>';
$links .= '<a href="http://pinterest.com/pin/create/link/?url=' . $url . '" target="_blank"><i class="fa fa-fw fa-whatsapp"></i> Send</a>';
$links .= '<a href="http://vk.com/share.php?url=' . $url . '&title=' . $title . '&comment=' . $text . '" target="_blank"><i class="fa fa-fw fa-whatsapp"></i> Send</a>';
$links .= '<a href="http://widget.renren.com/dialog/share?resourceUrl=' . $url . '&srcUrl=' . $url . '&title=' . $title . '&description=' . $text . '" target="_blank"><i class="fa fa-fw fa-whatsapp"></i> Send</a>';
$links .= '<a href="http://www.addthis.com/bookmark.php?url=' . $url . '" target="_blank"><i class="fa fa-fw fa-whatsapp"></i> Send</a>';
$links .= '<a href="http://www.douban.com/recommend/?url=' . $url . '&title=' . $title . '" target="_blank"><i class="fa fa-fw fa-whatsapp"></i> Send</a>';
$links .= '<a href="http://www.evernote.com/clip.action?url=' . $url . '&title=' . $title . '';
$links .= '<a href="http://www.instapaper.com/edit?url=' . $url . '&title=' . $title . '&description=' . $text . '';
$links .= '<a href="http://www.livejournal.com/update.bml?subject=' . $title . '&event=' . $url . '';
$links .= '<a href="https://buffer.com/add?text=' . $title . '&url=' . $url . '';
$links .= '<a href="https://connect.ok.ru/dk?st.cmd=WidgetSharePreview&st.shareUrl=' . $url . '';
$links .= '<a href="https://flattr.com/submit/auto?user_id=' . $user_id . '&url=' . $url . '&title=' . $title . '&description=' . $text . '&language={language_code}&tags=' . $hashtags . '&hidden=HIDDEN&category={category}';
$links .= '<a href="https://getpocket.com/edit?url=' . $url . '';
$links .= '<a href="https://lineit.line.me/share/ui?url=' . $url . '&text=' . $text . '';
$links .= '<a href="https://reddit.com/submit?url=' . $url . '&title=' . $title . '';
$links .= '<a href="https://share.diasporafoundation.org/?title=' . $title . '&url=' . $url . '';
$links .= '<a href="https://share.flipboard.com/bookmarklet/popout?v=2&title=' . $title . '&url=' . $url . '';
$links .= '<a href="https://web.skype.com/share?url=' . $url . '&text=' . $text . '';
$links .= '<a href="https://www.google.com/bookmarks/mark?op=edit&bkmk=' . $url . '&title=' . $title . '&annotation=' . $text . '&labels=' . $hashtags . '';
$links .= '<a href="https://www.linkedin.com/shareArticle?mini=true&url=' . $url . '&title=' . $title . '&summary=' . $text . '&source=' . $provider;
$links .= '<a href="https://www.tumblr.com/widgets/share/tool?canonicalUrl=' . $url . '&title=' . $title . '&caption=' . $text . '&tags=' . $hashtags . '';
$links .= '<a href="https://www.xing.com/spi/shares/new?url=' . $url . '';
*/
	
	return $links;
}










function ware_var($id,$key,$text) {
	$vars = get_post_meta($id,$key,true);
	$output = '';
	
	if( $vars ) {
		$output .= '<div class="variable-list">';
			$output .= '<p>' . $text . '</p>';
			$vars = maybe_unserialize($vars);
			$c = 1;
			foreach( $vars as $var ) {
				$checked = ( $c == 1 ) ? 'checked=checked' : '';
				$output .= '<input id="' . $key . '-' . $c . '" type="radio" name="' . $key . '" value="' . $var . '" ' . $checked . '><label for="' . $key . '-' . $c . '">' . $var . '</label>';
				$c++;
			}
		$output .= '</div>';
	}
	
	return $output;
}

function render_banners() {
	if( !is_singular() ) {
		$x = get_option('noel_theme_options');
		$x = maybe_unserialize($x)['banners'];
		
		$output = '<div id="main-banner" class="owl-carousel owl-theme">';
			foreach( $x as $key => $val ) {
				$output .= '<div class="item"><img src="' . wp_get_attachment_image_src($key,'full')[0] . '" /></div>';
			}
		$output .= '</div>';
		
		return $output;
	}
}

add_action('wp_head', 'shadyMeta');
function shadyMeta() {
	$title = get_bloginfo('name');
	$desc = __( 'Just another ShadyThemes\'s work.', 'ShadyPlugin' );
	$image = get_option( 'shady_og_pic', 'https://4.bp.blogspot.com/-v80ekLmyvyo/WXxFf-PSYYI/AAAAAAAABmo/JxL1CjL-d9A6aocEXjW61-BhSyxF38gfACK4BGAYYCw/s1600/shadyog.jpg' );
	$url = home_url('/');

	echo '<meta name="description" content="' . $desc . '" />';

	echo '<link rel="author" href="https://plus.google.com/u/0/103450196813182558966"/>';
	echo '<link rel="publisher" href="https://plus.google.com/b/107877753218676622461/"/>';
	echo '<meta itemprop="name" content="' . $title . '">';
	echo '<meta itemprop="description" content="' . $desc . '">';
	echo '<meta itemprop="image" content="' . $image . '">';

	echo '<meta property="og:locale" content="' . get_locale() . '" />';
	echo '<meta property="og:type" content="website" />';
	echo '<meta property="og:title" content="' . $title . '" />';
	echo '<meta property="og:description" content="' . $desc . '" />';
	echo '<meta property="og:url" content="' . $url . '" />';
	echo '<meta property="og:site_name" content="' . $title . '" />';
	echo '<meta property="og:image" content="' . $image . '" />';
	echo '<meta property="fb:app_id" content="1054643781230203" /> ';
	echo '<meta property="fb:admins" content="https://www.facebook.com/pencukurbumi" /> ';

	echo '<meta name="twitter:card" content="summary_large_image">';
	echo '<meta name="twitter:site" content="@shadythemes">';
	echo '<meta name="twitter:title" content="' . $title . '">';
	echo '<meta name="twitter:description" content="' . $desc . '">';
	echo '<meta name="twitter:creator" content="@shadythemes">';
	echo '<meta name="twitter:image:src" content="' . $image . '"> ';
}




add_action( 'rest_api_init', 'create_api_posts_meta_field' );
function create_api_posts_meta_field() {
    // register_rest_field ( 'name-of-post-type', 'name-of-field-to-return', array-of-callbacks-and-schema() )
    register_rest_field( 'ware', 'noel_custom_fields', array(
           'get_callback'    => 'get_post_meta_for_api',
           'schema'          => null,
        )
    );
}
function get_post_meta_for_api( $object ) {
    //get the id of the post object array
    $post_id = $object['id'];
 
    //return the post meta
    // return get_post_meta( $post_id );
    return array(
		'price' => get_post_meta($post_id,'ware_price',true),
		'sale_price' => get_post_meta($post_id,'ware_price_sale',true),
		'fimage' => get_fimage($post_id),
	);
}